#include "Course.h"

Course::Course(const std::string& courseName, int courseCredits)
    : name(courseName), credits(courseCredits), faculty(""), classroom(""), slot(-1) {}

std::string Course::getName() const { return name; }
int Course::getCredits() const { return credits; }
std::string Course::getFaculty() const { return faculty; }
std::string Course::getClassroom() const { return classroom; }
int Course::getSlot() const { return slot; }

void Course::setCredits(int c) { credits = c; }
void Course::setFaculty(const std::string& f) { faculty = f; }
void Course::setClassroom(const std::string& c) { classroom = c; }
void Course::setSlot(int s) { slot = s; }

bool Course::isScheduled() const { return slot != -1; }
