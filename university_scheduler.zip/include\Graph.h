#ifndef GRAPH_H
#define GRAPH_H

#include <string>
#include <vector>
#include <map>
#include <set>

/*
 * Graph
 * -----
 * Directed graph representing prerequisite relationships between courses.
 *
 * Node        = a course name
 * Edge A -> B = "A is a prerequisite of B" (A must be completed/scheduled
 *               before B).
 *
 * Implementation: adjacency list using std::map<string, vector<string>>.
 * A map (not unordered_map) is used so iteration order is deterministic,
 * which keeps output reproducible across runs.
 *
 * insertionOrder additionally records the order courses were added in,
 * since Kahn's algorithm needs a stable starting order for nodes that
 * all have indegree 0 (ties are broken by insertion order, matching the
 * expected sample output).
 */
class Graph {
private:
    std::map<std::string, std::vector<std::string>> adjList;
    std::map<std::string, int> indegree;
    std::vector<std::string> insertionOrder;

public:
    // Remove all nodes and edges from the graph
    void clear();

    // Add a course node to the graph (no-op if it already exists)
    void addCourseNode(const std::string& name);

    // Add a directed edge "from -> to" meaning `from` is a prerequisite of `to`.
    // Returns false if either node does not exist in the graph.
    bool addEdge(const std::string& from, const std::string& to);

    bool hasCourse(const std::string& name) const;

    const std::map<std::string, std::vector<std::string>>& getAdjList() const;
    const std::map<std::string, int>& getIndegree() const;
    const std::vector<std::string>& getInsertionOrder() const;

    int getNumCourses() const;

    // Print adjacency list as readable text, e.g.
    //   DSA -> DBMS, OS
    //   OOP -> CN
    void displayGraph() const;
};

#endif // GRAPH_H
