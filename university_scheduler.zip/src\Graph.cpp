#include "Graph.h"
#include <iostream>

void Graph::clear() {
    adjList.clear();
    indegree.clear();
    insertionOrder.clear();
}

void Graph::addCourseNode(const std::string& name) {
    if (adjList.find(name) == adjList.end()) {
        adjList[name] = std::vector<std::string>();
        indegree[name] = 0;
        insertionOrder.push_back(name);
    }
    // If it already exists, do nothing (idempotent add).
}

bool Graph::addEdge(const std::string& from, const std::string& to) {
    if (!hasCourse(from) || !hasCourse(to)) {
        return false; // one or both courses were never added
    }
    if (from == to) {
        return false; // a course cannot be its own prerequisite
    }
    // Ignore duplicate edges so indegree is not inflated
    for (const auto& neighbor : adjList[from]) {
        if (neighbor == to) {
            return true;
        }
    }
    adjList[from].push_back(to);
    indegree[to]++;
    return true;
}

bool Graph::hasCourse(const std::string& name) const {
    return adjList.find(name) != adjList.end();
}

const std::map<std::string, std::vector<std::string>>& Graph::getAdjList() const {
    return adjList;
}

const std::map<std::string, int>& Graph::getIndegree() const {
    return indegree;
}

const std::vector<std::string>& Graph::getInsertionOrder() const {
    return insertionOrder;
}

int Graph::getNumCourses() const {
    return static_cast<int>(insertionOrder.size());
}

void Graph::displayGraph() const {
    if (adjList.empty()) {
        std::cout << "Graph is empty. Add courses first.\n";
        return;
    }
    std::cout << "\n--- Course Prerequisite Graph (adjacency list) ---\n";
    // Iterate in insertion order so output is intuitive to the user
    for (const auto& course : insertionOrder) {
        std::cout << course << " -> ";
        const auto& neighbors = adjList.at(course);
        if (neighbors.empty()) {
            std::cout << "(no dependent courses)";
        } else {
            for (size_t i = 0; i < neighbors.size(); ++i) {
                std::cout << neighbors[i];
                if (i + 1 < neighbors.size()) std::cout << ", ";
            }
        }
        std::cout << "  [indegree=" << indegree.at(course) << "]\n";
    }
    std::cout << "---------------------------------------------------\n";
}
