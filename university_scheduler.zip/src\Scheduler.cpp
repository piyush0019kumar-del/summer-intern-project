#include "Scheduler.h"
#include <iostream>
#include <fstream>
#include <queue>

Scheduler::Scheduler(Graph& g, std::map<std::string, Course>& courseTable)
    : graph(g), courses(courseTable), cycleDetected(false) {}

bool Scheduler::runKahnTopologicalSort() {
    topoOrder.clear();
    cycleNodes.clear();
    cycleDetected = false;

    if (graph.getNumCourses() == 0) {
        std::cout << "No courses in the graph. Add courses first.\n";
        return false;
    }

    // Work on a local copy of indegree so repeated runs don't corrupt graph state.
    std::map<std::string, int> localIndegree = graph.getIndegree();
    const auto& adjList = graph.getAdjList();
    const auto& order = graph.getInsertionOrder(); // stable tie-break order

    // Step 1: enqueue all nodes with indegree 0, in insertion order.
    std::queue<std::string> q;
    for (const auto& course : order) {
        if (localIndegree[course] == 0) {
            q.push(course);
        }
    }

    // Step 2: standard BFS/Kahn's processing.
    while (!q.empty()) {
        std::string current = q.front();
        q.pop();
        topoOrder.push_back(current);

        // For every course that depends on `current`, reduce its indegree.
        auto it = adjList.find(current);
        if (it != adjList.end()) {
            for (const auto& neighbor : it->second) {
                localIndegree[neighbor]--;
                if (localIndegree[neighbor] == 0) {
                    q.push(neighbor);
                }
            }
        }
    }

    // Step 3: if not all courses were processed, a cycle exists.
    if (static_cast<int>(topoOrder.size()) != graph.getNumCourses()) {
        cycleDetected = true;
        // Any course with indegree still > 0 is part of (or downstream of) a cycle.
        for (const auto& course : order) {
            if (localIndegree[course] > 0) {
                cycleNodes.push_back(course);
            }
        }
        return false;
    }

    return true;
}

const std::vector<std::string>& Scheduler::getTopoOrder() const {
    return topoOrder;
}

bool Scheduler::isCycleDetected() const {
    return cycleDetected;
}

const std::vector<std::string>& Scheduler::getCycleNodes() const {
    return cycleNodes;
}

void Scheduler::generateTimetable() {
    timetable.clear();
    facultyBookedPerSlot.clear();
    classroomBookedPerSlot.clear();

    if (topoOrder.empty()) {
        std::cout << "No valid topological order available. Run option 4 "
                     "(Generate Timetable) only after courses/prerequisites "
                     "are set up correctly.\n";
        return;
    }

    // Simple, clash-free strategy: each course in topological order gets
    // its own slot. Because the order respects all prerequisite edges,
    // no course is ever scheduled before its prerequisite -- this is
    // exactly what "clash-free" means in this context.
    int slot = 1;
    for (const auto& courseName : topoOrder) {
        timetable[slot] = courseName;
        if (courses.find(courseName) != courses.end()) {
            courses.at(courseName).setSlot(slot);
        }
        slot++;
    }
}

bool Scheduler::isTimetableGenerated() const {
    return !timetable.empty();
}

void Scheduler::displayTimetable() const {
    if (timetable.empty()) {
        std::cout << "Timetable has not been generated yet. Use option 4 first.\n";
        return;
    }
    std::cout << "\n--- Generated Timetable ---\n";
    for (const auto& entry : timetable) {
        std::cout << "Slot " << entry.first << ": " << entry.second;
        auto it = courses.find(entry.second);
        if (it != courses.end()) {
            if (!it->second.getFaculty().empty()) {
                std::cout << "  | Faculty: " << it->second.getFaculty();
            }
            if (!it->second.getClassroom().empty()) {
                std::cout << "  | Room: " << it->second.getClassroom();
            }
        }
        std::cout << "\n";
    }
    std::cout << "----------------------------\n";
}

bool Scheduler::assignFacultyClassroom(const std::string& courseName,
                                        const std::string& facultyName,
                                        const std::string& classroomName) {
    if (courses.find(courseName) == courses.end()) {
        std::cout << "Course \"" << courseName << "\" does not exist.\n";
        return false;
    }
    Course& c = courses.at(courseName);
    if (!c.isScheduled()) {
        std::cout << "Course \"" << courseName << "\" has no slot yet. "
                     "Generate the timetable first.\n";
        return false;
    }
    int slot = c.getSlot();

    // Overlap checks: same faculty or same classroom cannot be double
    // booked in the same slot.
    if (facultyBookedPerSlot[slot].count(facultyName)) {
        std::cout << "Clash detected: faculty \"" << facultyName
                  << "\" is already teaching another course in slot " << slot << ".\n";
        return false;
    }
    if (classroomBookedPerSlot[slot].count(classroomName)) {
        std::cout << "Clash detected: classroom \"" << classroomName
                  << "\" is already booked in slot " << slot << ".\n";
        return false;
    }

    c.setFaculty(facultyName);
    c.setClassroom(classroomName);
    facultyBookedPerSlot[slot].insert(facultyName);
    classroomBookedPerSlot[slot].insert(classroomName);

    std::cout << "Assigned faculty \"" << facultyName << "\" and classroom \""
              << classroomName << "\" to " << courseName << " (slot " << slot << ").\n";
    return true;
}

void Scheduler::reset() {
    topoOrder.clear();
    cycleNodes.clear();
    cycleDetected = false;
    timetable.clear();
    facultyBookedPerSlot.clear();
    classroomBookedPerSlot.clear();
    for (auto& entry : courses) {
        entry.second.setSlot(-1);
        entry.second.setFaculty("");
        entry.second.setClassroom("");
    }
}

void Scheduler::saveTimetableToFile(const std::string& filename) const {
    if (timetable.empty()) {
        std::cout << "Nothing to save -- generate the timetable first.\n";
        return;
    }
    std::ofstream out(filename);
    if (!out.is_open()) {
        std::cout << "Could not open file \"" << filename << "\" for writing.\n";
        return;
    }
    out << "Generated Course Order:\n";
    for (size_t i = 0; i < topoOrder.size(); ++i) {
        out << topoOrder[i];
        if (i + 1 < topoOrder.size()) out << " -> ";
    }
    out << "\n\nGenerated Timetable:\n";
    for (const auto& entry : timetable) {
        out << "Slot " << entry.first << ": " << entry.second;
        auto it = courses.find(entry.second);
        if (it != courses.end()) {
            if (!it->second.getFaculty().empty())
                out << " | Faculty: " << it->second.getFaculty();
            if (!it->second.getClassroom().empty())
                out << " | Room: " << it->second.getClassroom();
        }
        out << "\n";
    }
    out.close();
    std::cout << "Timetable saved to \"" << filename << "\".\n";
}
