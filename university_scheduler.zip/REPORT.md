# Mini Project Report: University Course & Exam Scheduler

**Theme:** SIH Smart Education
**Technology:** C++, Graph Theory, BFS-based Topological Sorting (Kahn's Algorithm)

---

## 1. Abstract

Universities routinely produce course and exam timetables by hand or with
ad-hoc spreadsheets, which makes it easy to accidentally schedule a course
before its prerequisite, or to miss a contradictory prerequisite chain
altogether. This project implements a scheduler that treats courses as
nodes in a directed graph, prerequisite relationships as directed edges,
and uses Kahn's Algorithm (a BFS-based topological sort) to compute a
valid, clash-free ordering. Cyclic prerequisite chains — which make
scheduling mathematically impossible — are detected and reported rather
than silently producing a broken timetable. The system is delivered as a
menu-driven C++ console application with clean separation between data
(`Course`), structure (`Graph`), and algorithm (`Scheduler`).

## 2. Introduction

### 2.1 Problem Statement

Given a set of courses and a set of prerequisite relationships between
them, produce a course order (and by extension, a timetable) such that no
course is ever scheduled before any of its prerequisites — or correctly
report that no such order exists.

### 2.2 Why Graph Theory

Prerequisite relationships are naturally directed and can form complex
chains (A before B, B before C, A before D, etc). This is exactly what a
**Directed Graph** models. A valid schedule exists **if and only if** this
graph is a **DAG (Directed Acyclic Graph)** — i.e., it contains no cycles.
Topological sorting is the standard technique for turning a DAG into a
linear order that respects all edges.

### 2.3 Why Kahn's Algorithm (BFS-based) specifically

Topological sorting can be done two ways: DFS-based (using finish times)
or BFS-based (Kahn's Algorithm, using indegree counting). This project
uses Kahn's Algorithm because:

- It **naturally detects cycles** as a side effect (if not all nodes get
  processed, a cycle exists) — no separate cycle-detection pass needed.
- It processes nodes in **layers** (all currently-available courses, then
  the next wave, etc.), which maps intuitively onto "batches of courses
  that could be scheduled together."
- It's iterative (queue-based), avoiding recursion depth concerns that
  DFS-based approaches carry for very large course catalogs.

## 3. Methodology

### 3.1 Data Model

| Component | Representation |
|---|---|
| Course | `Course` class — name, credits, faculty, classroom, assigned slot |
| Prerequisite `A -> B` | Directed edge from `A` to `B` in `Graph`'s adjacency list |
| Course catalog | `std::map<std::string, Course>` (in `main.cpp`) |
| Graph structure | `std::map<std::string, std::vector<std::string>>` adjacency list + `std::map<std::string, int>` indegree count |

A `std::map` (not `unordered_map`) is used for the adjacency list so
iteration order is deterministic — useful for reproducible output and
debugging. A separate `insertionOrder` vector in `Graph` records the order
courses were added, since Kahn's algorithm needs a stable tie-break rule
for the (very common) case where multiple courses have zero prerequisites
at the same time.

### 3.2 Algorithm — Kahn's Algorithm (BFS-based Topological Sort)

**Steps implemented in `Scheduler::runKahnTopologicalSort()`:**

1. Compute indegree (number of incoming prerequisite edges) for every
   course. This is maintained incrementally in `Graph` as edges are added.
2. Push all courses with indegree 0 into a queue, in the order they were
   originally added (insertion order) — these are courses with no
   unmet prerequisites.
3. While the queue is not empty:
   - Dequeue a course, append it to the result order.
   - For every course that depends on it (its neighbors in the adjacency
     list), decrement that course's indegree by 1.
   - If a neighbor's indegree drops to 0, it has no more unmet
     prerequisites — enqueue it.
4. After the loop, if the result order contains every course, the sort
   succeeded — this order is a valid schedule. If it contains fewer
   courses than exist in the graph, the remaining courses are stuck
   waiting on each other — a **cycle** exists among them.

### 3.3 Timetable Generation

Once a valid topological order exists, `Scheduler::generateTimetable()`
assigns slot 1 to the first course in the order, slot 2 to the second, and
so on. Because the order already respects every prerequisite edge, this
is clash-free by construction — no course can ever land in a slot before
its prerequisite's slot.

### 3.4 Optional Faculty/Classroom Assignment

`Scheduler::assignFacultyClassroom()` looks up the slot a course was
placed in, then checks two sets (`facultyBookedPerSlot[slot]` and
`classroomBookedPerSlot[slot]`) to reject an assignment that would double-
book a faculty member or room within the same slot. See README.md Section
6 for an honest note on why this rarely triggers under the current
one-course-per-slot model.

## 4. Results

Running the tool against the exact dataset from the project specification:

**Input:**
```
Courses: DSA, OOP, DBMS, OS, CN
Prerequisites: DSA->DBMS, DSA->OS, OOP->CN, DBMS->CN
```

**Output (verified by direct execution, not hand-traced):**
```
Generated Course Order:
DSA -> OOP -> DBMS -> OS -> CN

Slot 1: DSA
Slot 2: OOP
Slot 3: DBMS
Slot 4: OS
Slot 5: CN
```

This is an exact match to the specification's expected output.

**Cycle detection test:** courses `X, Y, Z` with edges `X->Y, Y->Z, Z->X`
were added, and option 6 correctly reported all three as being involved in
a cycle, and option 4 correctly refused to generate a timetable, printing
the offending courses instead of silently producing an invalid order.

**File I/O test:** `sample_input.txt` was loaded via option 9 and produced
identical output to the built-in sample dataset, confirming the file
parser and the in-memory path are consistent.

## 5. Time and Space Complexity Analysis

Let `V` = number of courses, `E` = number of prerequisite relationships.

| Operation | Time Complexity | Notes |
|---|---|---|
| Add course | O(log V) | `std::map` insertion |
| Add edge | O(log V) | map lookup for both endpoints |
| Kahn's Algorithm (full run) | **O(V + E)** | Each node enqueued/dequeued once; each edge relaxed (indegree decrement) exactly once |
| Timetable generation | O(V) | One pass over the topological order |
| Cycle node collection | O(V) | One pass to find leftover positive indegrees |
| Faculty/classroom check | O(log V) per assignment | Map + set lookups |
| Display graph | O(V + E) | Must print every node and every edge |

**Space Complexity: O(V + E)**
- Adjacency list: O(V + E) — V keys, E total edge entries across all lists.
- Indegree map: O(V).
- Topological order / queue: O(V) at any point.
- Course data table: O(V).

The dominant cost is Kahn's Algorithm itself at **O(V + E)**, which is
optimal for this problem — you cannot produce a valid ordering without at
least inspecting every course and every prerequisite relationship once.

## 6. Conclusion

The project demonstrates that a well-known graph algorithm (Kahn's / BFS
topological sort) maps directly onto a real administrative problem:
producing a prerequisite-respecting course order, with built-in detection
of an invalid (cyclic) prerequisite configuration. The implementation
keeps a clean OOP separation between data (`Course`), structure (`Graph`),
and algorithm (`Scheduler`), which made it straightforward to test each
piece independently and to verify the output against the specification's
worked example exactly.

## 7. Limitations & Future Work

Stated directly, not as a footnote:

1. **One course per slot.** The current model doesn't pack independent
   courses (no path between them) into the same slot for parallel
   scheduling. A more realistic exam timetable would process Kahn's
   Algorithm **layer by layer** (all courses dequeued from the "ready"
   queue *before* any new courses become ready form one layer/slot), and
   allow multiple courses to share a slot as long as they don't clash on
   faculty or classroom. This would also make the faculty/classroom
   overlap check functionally meaningful, not just structurally present.
2. **No time-slot capacity limits.** Real universities have a finite
   number of exam halls/periods per day. This isn't modeled.
3. **No weighted priorities.** All courses are treated as equally
   urgent; core/elective distinctions aren't considered.
4. **Cycle reporting is coarse.** The system reports *all* courses with
   leftover indegree after Kahn's algorithm finishes, which includes
   both the actual cycle and any courses downstream of it. A DFS-based
   pass could isolate the exact cycle, at the cost of extra complexity.

These are natural next steps if this were extended beyond a mini-project
scope.
